# 😌 Sakin Kal — Berat ve Kardelen

## Bu pakette neler var?
- Mobil uyumlu sayaç arayüzü
- Berat ve Kardelen için bağımsız 20 hak sayacı
- Firebase Realtime Database ile canlı senkronizasyon
- 24 saatlik süre dolduğunda sayfaya yeniden girildiğinde sıfırlama
- Kota sıfıra indiğinde uyarı ve isteğe bağlı yerel müzik dosyası
- Telifli şarkı gömülü değildir

## Önemli sınırlar
Bu, Firebase bilgileri girilmeden internette çalışmaya hazır değildir. Bu ortamdan Firebase projenizi oluşturamam veya siteyi sizin adınıza yayımlayamam. Kod bu pakette hazırlanmıştır; gerçek çevrim içi kullanım için aşağıdaki kurulum gerekir.

Bu örnekte sıfırlama, bir kullanıcı siteyi açtığında kontrol edilir. Site kapalıyken sunucu tarafında tam zamanında tetiklenen bir işlem değildir; süre dolduktan sonra tekrar açıldığında sıfırlar. Daha güçlü güvenlik ve sunucu otoriteli sıfırlama için Cloud Functions/benzeri sunucu kodu gerekir.

Veritabanı kuralları yalnızca oturum açmış kullanıcıların erişimine izin verir. Firebase Email/Password kullanıcıları oluşturun ve anonim kimlik doğrulamayı açmayın. Bu temel örnek, oturum açmış her kullanıcının iki sayacı da değiştirmesine izin verir; hesapların dışında kesin kişi bazlı yetkilendirme için daha sıkı kurallar ve kullanıcı UID eşlemesi gerekir.

## 1. Firebase projesi
1. https://console.firebase.google.com/ adresine gidin ve bir proje oluşturun.
2. Project settings > General > Your apps > Web app bölümünden web uygulaması ekleyin.
3. Firebase yapılandırma nesnesini `firebase-config.js` dosyasına kopyalayın.
4. Build > Authentication > Sign-in method bölümünden **Email/Password** yöntemini etkinleştirin.
5. Build > Realtime Database bölümünden veritabanı oluşturun. Bölgeyi seçin.
6. Realtime Database > Rules bölümüne `database.rules.json` içeriğini yapıştırın ve yayımlayın.
7. Authentication > Users bölümünden Berat ve Kardelen için iki hesap oluşturun. Giriş e-posta ve şifreleri paylaşılmamalıdır.

## 2. Yerel test
Bu proje JavaScript modülleri kullandığından dosyayı doğrudan `file://` üzerinden açmayın. Bilgisayarda Python kuruluysa klasörde terminal açıp:
`python -m http.server 8000`
komutunu çalıştırın, ardından `http://localhost:8000` adresine gidin.

## 3. Firebase Hosting ile yayımlama
1. Node.js kurun: https://nodejs.org/
2. Terminalde `npm install -g firebase-tools` çalıştırın.
3. Proje klasöründe `firebase login` ve `firebase init hosting` komutlarını çalıştırın.
4. Public directory olarak `.` seçin; tek sayfalı uygulama yönlendirmesi sorulursa `No` seçin. Var olan `index.html` dosyasının üzerine yazmayı seçmeyin.
5. `firebase deploy` komutunu çalıştırın.
6. Komutun verdiği HTTPS adresini iki telefonunuzda da açın.

## 4. İsteğe bağlı müzik
Yasal olarak kullanma hakkınız bulunan ses dosyasını `music.mp3` adıyla bu klasöre ekleyin. Telifli Pinhani kaydı pakete dahil değildir. Tarayıcı otomatik oynatmayı engellerse ekrandaki müziği başlat düğmesine basın. Bazı yerleştirilebilir müzik platformları otomatik oynatmaya izin vermez.

## 5. Önemli teknik notlar
- İki telefonun aynı Firebase projesine bağlanması gerekir.
- Sayaç işlemleri transaction kullanır; eşzamanlı basışlarda aynı hakkın iki kez düşmesi önlenir.
- Her sayaç 0'ın altına inmez.
- Süre kontrolü istemci tarafındadır. Kötü niyetli kullanıcı sistem saatini değiştirebilir; daha sağlam kullanım için sunucu zamanı ve Cloud Functions gerekir.
- Bu pakette otomatik test veya gerçek Firebase projesine karşı canlı test yapılmamıştır.
